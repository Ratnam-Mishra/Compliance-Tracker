import React, { useState } from "react";
import DocumentTable from "../components/DocumentTable";
import SearchBox from "../components/SearchBox";
import { UploadCloud } from "lucide-react";

const Documents: React.FC = () => {
  const [query, setQuery] = useState("");
  const [uploading, setUploading] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setUploading(true);

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result?.toString().split(",")[1];
      if (!base64) return;

      try {
        const res = await fetch(
          "http://localhost:5000/api/compliance/UploadFileToSP",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: file.name, fileBase64: base64 }),
          }
        );

        const json = await res.json();
        alert(json.status ? "✅ Upload successful" : "❌ Upload failed");
      } catch (err) {
        alert("❌ Upload failed due to error.");
      } finally {
        setUploading(false);
      }
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="h-228 w-full p-10 bg-neutral-100">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold text-neutral-900">Document Viewer</h1>
        <div className="flex gap-4 items-center">
          <SearchBox value={query} onChange={setQuery} />

          <label className="flex items-center gap-2 cursor-pointer px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-medium shadow hover:bg-red-600 transition">
            <UploadCloud className="w-4 h-4" />
            {uploading ? "Uploading..." : "Upload File"}
            <input
              type="file"
              onChange={handleFileUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
        </div>
      </div>

      {fileName && (
        <p className="text-sm text-neutral-600 mb-4 ml-auto w-fit italic">
          Selected: <span className="font-semibold">{fileName}</span>
        </p>
      )}

      <DocumentTable searchQuery={query} />
    </div>
  );
};

export default Documents;

// import React, { useState } from "react";
// import DocumentTable from "../components/DocumentTable";
// import SearchBox from "../components/SearchBox";

// const Documents: React.FC = () => {
//   const [query, setQuery] = useState("");

//   return (
//     <div className="h-228 w-full p-10 bg-neutral-100">
//       <div className="flex items-center justify-between mb-8">
//         <h1 className="text-4xl font-bold text-neutral-900">Document Viewer</h1>
//         <SearchBox value={query} onChange={setQuery} />
//       </div>

//       <DocumentTable searchQuery={query} />
//     </div>
//   );
// };

// export default Documents;
