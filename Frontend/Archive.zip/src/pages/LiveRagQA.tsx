// src/pages/LiveRagQA.tsx
import React from "react";
import QueryInput from "../components/QueryInput";
import AnswerPanel from "../components/AnswerPanel";
import SourceViewer from "../components/SourceViewer";
import VoiceInput from "../components/VoiceInput";
import ChatHistory from "../components/ChatHistory";

const LiveRagQA: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-100 p-8">
      <header className="text-3xl font-bold text-neutral-800 mb-8">
        Live Compliance Q&A
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        <div className="col-span-2 space-y-6">
          <QueryInput />
          <AnswerPanel />
          <SourceViewer />
        </div>

        <div className="space-y-6">
          <VoiceInput />
          <ChatHistory />
        </div>
      </div>
    </div>
  );
};

export default LiveRagQA;
