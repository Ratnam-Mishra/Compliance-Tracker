// src/components/AnswerPanel.tsx
import React from "react";

const AnswerPanel: React.FC = () => {
  const dummyAnswer =
    "No, employees are strictly prohibited from sharing any confidential data with external parties without prior authorization from the Compliance Officer.";

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold text-neutral-800 mb-4">Answer</h2>
      <p className="text-neutral-700 leading-relaxed">{dummyAnswer}</p>
    </div>
  );
};

export default AnswerPanel;
