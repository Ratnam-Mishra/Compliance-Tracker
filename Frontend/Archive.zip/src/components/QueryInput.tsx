// src/components/QueryInput.tsx
import React, { useState } from "react";

const QueryInput: React.FC = () => {
  const [query, setQuery] = useState("");

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold text-neutral-800 mb-4">
        Ask a Compliance Question
      </h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="e.g., Are employees allowed to share confidential data externally?"
        className="w-full p-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 transition"
      />
    </div>
  );
};

export default QueryInput;
