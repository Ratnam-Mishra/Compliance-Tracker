import React, { useEffect, useMemo, useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  flexRender,
} from "@tanstack/react-table";

type Employee = {
  email: string;
  displayName: string;
  department: string;
  count: number;
};

const ReportedEmployees: React.FC = () => {
  const [globalFilter, setGlobalFilter] = useState("");
  const [data, setData] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch data from backend API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(
          "http://localhost:5000/api/compliance/employees"
        );
        if (!res.ok) throw new Error("Failed to fetch employees");
        const json = await res.json();
        setData(json);
      } catch (err: any) {
        setError(err.message || "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const columns = useMemo(
    () => [
      {
        accessorKey: "displayName",
        header: "Employee",
      },
      {
        accessorKey: "count",
        header: "Violations",
      },
      {
        accessorKey: "department",
        header: "Department",
      },
    ],
    []
  );

  const table = useReactTable({
    data,
    columns,
    state: {
      globalFilter,
    },
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow h-150 flex flex-col">
      <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
        Flagged Employees
      </h2>

      {loading && <p className="text-sm text-neutral-500">Loading...</p>}
      {error && <p className="text-sm text-red-500">Error: {error}</p>}

      {!loading && !error && (
        <>
          <input
            type="text"
            placeholder="Search employees..."
            value={globalFilter ?? ""}
            onChange={(e) => setGlobalFilter(e.target.value)}
            className="border border-neutral-300 rounded-lg px-3 py-2 text-sm text-neutral-700 focus:ring-2 focus:ring-red-400 focus:outline-none mb-4 w-1/2"
          />

          <div className="overflow-x-auto">
            <table className="w-full text-left text-neutral-700 border-collapse">
              <thead className="bg-neutral-100 sticky top-0 z-10">
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr
                    key={headerGroup.id}
                    className="text-neutral-500 text-sm border-b border-neutral-200"
                  >
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        onClick={header.column.getToggleSortingHandler()}
                        className="py-3 px-4 cursor-pointer select-none"
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        {header.column.getIsSorted() === "asc" ? " ▲" : ""}
                        {header.column.getIsSorted() === "desc" ? " ▼" : ""}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
            </table>
          </div>

          <div className="overflow-y-auto max-h-96">
            <table className="w-full text-left text-neutral-700">
              <tbody>
                {table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.id}
                    className="hover:bg-neutral-50 transition-colors text-sm"
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="py-3 px-4 font-medium">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
};

export default ReportedEmployees;

// import React, { useEffect, useMemo, useState } from "react";
// import {
//   useReactTable,
//   getCoreRowModel,
//   getFilteredRowModel,
//   getSortedRowModel,
//   flexRender,
// } from "@tanstack/react-table";

// type Employee = {
//   displayName: string;
//   department: string;
//   count: number;
// };

// const ReportedEmployees: React.FC = () => {
//   const [globalFilter, setGlobalFilter] = useState("");
//   const [data, setData] = useState<Employee[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await fetch("http://localhost:5000/api/compliance/employees");
//         if (!res.ok) throw new Error("Failed to fetch employees");
//         const json = await res.json();
//         setData(json);
//       } catch (err: any) {
//         setError(err.message || "Unknown error");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, []);

//   // const data = useMemo(
//   //   () => [
//   //     { name: "John Doe", violations: 5, department: "Finance" },
//   //     { name: "Jane Smith", violations: 3, department: "HR" },
//   //     { name: "Robert Brown", violations: 2, department: "IT" },
//   //     { name: "Alice Johnson", violations: 7, department: "Legal" },
//   //     { name: "Michael Lee", violations: 4, department: "Operations" },
//   //     { name: "Emily Davis", violations: 6, department: "Marketing" },
//   //     { name: "William Harris", violations: 8, department: "Sales" },
//   //     { name: "Olivia Martinez", violations: 1, department: "Compliance" },
//   //     { name: "Daniel Wilson", violations: 3, department: "Finance" },
//   //     { name: "Sophia Clark", violations: 9, department: "Legal" },
//   //     { name: "James Lewis", violations: 5, department: "IT" },
//   //     { name: "Lily Walker", violations: 2, department: "Operations" },
//   //     { name: "Henry Hall", violations: 4, department: "Compliance" },
//   //     { name: "Ella Young", violations: 6, department: "HR" },
//   //     { name: "Noah King", violations: 7, department: "Sales" },
//   //     { name: "Mia Wright", violations: 3, department: "Marketing" },
//   //     { name: "Liam Scott", violations: 1, department: "IT" },
//   //     { name: "Ava Green", violations: 4, department: "Finance" },
//   //     { name: "Benjamin Adams", violations: 2, department: "Legal" },
//   //     { name: "Charlotte Nelson", violations: 5, department: "Sales" },
//   //   ],
//   //   []
//   // );

//   const columns = useMemo(
//     () => [
//       {
//         accessorKey: "name",
//         header: "Employee",
//       },
//       {
//         accessorKey: "violations",
//         header: "Violations",
//       },
//       {
//         accessorKey: "department",
//         header: "Department",
//       },
//     ],
//     []
//   );

//   const table = useReactTable({
//     data,
//     columns,
//     state: {
//       globalFilter,
//     },
//     onGlobalFilterChange: setGlobalFilter,
//     getCoreRowModel: getCoreRowModel(),
//     getFilteredRowModel: getFilteredRowModel(),
//     getSortedRowModel: getSortedRowModel(),
//   });

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow h-150 flex flex-col">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
//         Flagged Employees
//       </h2>

//       {loading && <p className="text-sm text-neutral-500">Loading...</p>}
//       {error && <p className="text-sm text-red-500">Error: {error}</p>}

//       {!loading && !error && (
//         <>
//       <input
//         type="text"
//         placeholder="Search employees..."
//         value={globalFilter ?? ""}
//         onChange={(e) => setGlobalFilter(e.target.value)}
//         className="border border-neutral-300 rounded-lg px-3 py-2 text-sm text-neutral-700 focus:ring-2 focus:ring-red-400 focus:outline-none mb-4 w-1/2"
//       />

//       <div className="overflow-x-auto">
//         <table className="w-full text-left text-neutral-700 border-collapse">
//           <thead className="bg-neutral-100 sticky top-0 z-10">
//             {table.getHeaderGroups().map((headerGroup) => (
//               <tr
//                 key={headerGroup.id}
//                 className="text-neutral-500 text-sm border-b border-neutral-200"
//               >
//                 {headerGroup.headers.map((header) => (
//                   <th
//                     key={header.id}
//                     onClick={header.column.getToggleSortingHandler()}
//                     className="py-3 px-4 cursor-pointer select-none"
//                   >
//                     {flexRender(
//                       header.column.columnDef.header,
//                       header.getContext()
//                     )}
//                     {header.column.getIsSorted() === "asc" ? " ▲" : ""}
//                     {header.column.getIsSorted() === "desc" ? " ▼" : ""}
//                   </th>
//                 ))}
//               </tr>
//             ))}
//           </thead>
//         </table>
//       </div>

//       <div className="overflow-y-auto max-h-96">
//         <table className="w-full text-left text-neutral-700">
//           <tbody>
//             {table.getRowModel().rows.map((row) => (
//               <tr
//                 key={row.id}
//                 className="hover:bg-neutral-50 transition-colors text-sm"
//               >
//                 {row.getVisibleCells().map((cell) => (
//                   <td key={cell.id} className="py-3 px-4 font-medium">
//                     {flexRender(cell.column.columnDef.cell, cell.getContext())}
//                   </td>
//                 ))}
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// };

// export default ReportedEmployees;
