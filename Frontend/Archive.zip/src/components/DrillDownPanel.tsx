import React, { useState } from "react";
import ViolationPreview from "./ViolationPreview";

type Violation = {
  email: string;
  displayName: string;
  violationExplanation: string;
};

const DrillDownPanel: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  // ✅ Static mock data
  const violations: Violation[] = [
    {
      email: "aman@sharepointguides.com",
      displayName: "Aman Panjwani",
      violationExplanation:
        "The email contains instances of password sharing, a temporary simplistic password, and credentials sharing which violates password security rules.",
    },
    {
      email: "aman@sharepointguides.com",
      displayName: "Aman Panjwani",
      violationExplanation:
        "The temporary password '12345678' mentioned in the email does not meet the complexity requirements of the policy.",
    },
    {
      email: "aman@sharepointguides.com",
      displayName: "Aman Panjwani",
      violationExplanation:
        "Password shared temporarily with '12345678' violates complexity requirements and the policy that passwords should not be shared.",
    },
    {
      email: "aman@sharepointguides.com",
      displayName: "Aman Panjwani",
      violationExplanation:
        "Credentials shared with another team member ('Raj') for access to sensitive financial reports violates the policy regarding not sharing passwords.",
    },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-md p-6 h-100 hover:shadow-lg transition-shadow">
      <h2 className="text-2xl font-semibold text-neutral-900 mb-6">
        Violation Details
      </h2>

      <ul className="space-y-3">
        {violations.map((violation, index) => (
          <li
            key={index}
            className={`p-4 border rounded-xl cursor-pointer transition-colors ${
              selectedIndex === index
                ? "bg-neutral-100 border-red-400"
                : "border-neutral-200 hover:bg-neutral-50"
            }`}
            onClick={() => setSelectedIndex(index)}
          >
            <p className="text-neutral-700 truncate font-medium">
              {violation.violationExplanation}
              <span className="text-red-500 ml-2">
                [{violation.displayName}]
              </span>
            </p>
          </li>
        ))}
      </ul>

      {selectedIndex !== null && (
        <div className="mt-6">
          <ViolationPreview violation={violations[selectedIndex]} />
        </div>
      )}
    </div>
  );
};

export default DrillDownPanel;

// import React, { useEffect, useState } from "react";
// import ViolationPreview from "./ViolationPreview";

// type Violation = {
//   email: string;
//   displayName: string;
//   violationExplanation: string;
// };

// const DrillDownPanel: React.FC = () => {
//   const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
//   const [violations, setViolations] = useState<Violation[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   useEffect(() => {
//     const fetchViolations = async () => {
//       try {
//         const res = await fetch(
//           "http://localhost:5000/api/compliance/violations"
//         );
//         if (!res.ok) throw new Error("Failed to fetch violations");
//         const data = await res.json();
//         setViolations(data);
//       } catch (err: any) {
//         setError(err.message || "Unknown error");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchViolations();
//   }, []);

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 h-100 hover:shadow-lg transition-shadow">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-6">
//         Violation Details
//       </h2>

//       {loading && <p className="text-sm text-neutral-500">Loading...</p>}
//       {error && <p className="text-sm text-red-500">Error: {error}</p>}

//       {!loading && !error && (
//         <>
//           <ul className="space-y-3">
//             {violations.map((violation, index) => (
//               <li
//                 key={index}
//                 className={`p-4 border rounded-xl cursor-pointer transition-colors ${
//                   selectedIndex === index
//                     ? "bg-neutral-100 border-red-400"
//                     : "border-neutral-200 hover:bg-neutral-50"
//                 }`}
//                 onClick={() => setSelectedIndex(index)}
//               >
//                 <p className="text-neutral-700 truncate font-medium">
//                   {violation.violationExplanation}
//                   <span className="text-red-500 ml-2">
//                     [{violation.displayName}]
//                   </span>
//                 </p>
//               </li>
//             ))}
//           </ul>

//           {selectedIndex !== null && (
//             <div className="mt-6">
//               <ViolationPreview violation={violations[selectedIndex]} />
//             </div>
//           )}
//         </>
//       )}
//     </div>
//   );
// };

// export default DrillDownPanel;

// import React, { useState } from "react";
// import ViolationPreview from "./ViolationPreview";

// const DrillDownPanel: React.FC = () => {
//   const [selectedViolation, setSelectedViolation] = useState<string | null>(
//     null
//   );

//   const violations = [
//     {
//       id: "1",
//       content: "User sent confidential data to external recipient.",
//       keyword: "confidential",
//     },
//     {
//       id: "2",
//       content: "Potential phishing attempt detected in message sent by user.",
//       keyword: "phishing",
//     },
//     {
//       id: "3",
//       content: "Harassment language used in internal chat.",
//       keyword: "harassment",
//     },
//   ];

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 h-100 hover:shadow-lg transition-shadow">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-6">
//         Violation Details
//       </h2>
//       <ul className="space-y-3">
//         {violations.map((violation) => (
//           <li
//             key={violation.id}
//             className={`p-4 border rounded-xl cursor-pointer transition-colors ${
//               selectedViolation === violation.id
//                 ? "bg-neutral-100 border-red-400"
//                 : "border-neutral-200 hover:bg-neutral-50"
//             }`}
//             onClick={() => setSelectedViolation(violation.id)}
//           >
//             <p className="text-neutral-700 truncate font-medium">
//               {violation.content}
//               <span className="text-red-500 ml-2">[{violation.keyword}]</span>
//             </p>
//           </li>
//         ))}
//       </ul>

//       {selectedViolation && (
//         <div className="mt-6">
//           <ViolationPreview
//             violation={violations.find((v) => v.id === selectedViolation)!}
//           />
//         </div>
//       )}
//     </div>
//   );
// };

// export default DrillDownPanel;
