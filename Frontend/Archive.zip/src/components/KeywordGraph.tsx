import React, { useEffect, useState } from "react";
import ReactECharts from "echarts-for-react";

type KeywordFrequencyPoint = {
  date: string;
  frequency: number;
};

const KeywordGraph: React.FC = () => {
  const [data, setData] = useState<KeywordFrequencyPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(
          "http://localhost:5000/api/compliance/keyword-frequency"
        );
        if (!res.ok) throw new Error("Failed to fetch keyword data");
        const json = await res.json();
        setData(json);
      } catch (err: any) {
        setError(err.message || "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const option = {
    tooltip: {
      trigger: "axis",
    },
    grid: {
      left: "3%",
      right: "4%",
      bottom: "3%",
      containLabel: true,
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      data: data.map((point) => point.date),
      axisLabel: { color: "#6B7280" },
    },
    yAxis: {
      type: "value",
      axisLabel: { color: "#6B7280" },
    },
    series: [
      {
        name: "Frequency",
        type: "line",
        stack: "Total",
        smooth: true,
        lineStyle: {
          color: "#FA4616",
          width: 3,
        },
        itemStyle: {
          color: "#FA4616",
        },
        areaStyle: {
          color: "#FFECE6",
        },
        data: data.map((point) => point.frequency),
      },
    ],
  };

  return (
    <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
        Keyword Frequency Over Time
      </h2>

      {loading && <p className="text-sm text-neutral-500">Loading...</p>}
      {error && <p className="text-sm text-red-500">Error: {error}</p>}

      {!loading && !error && (
        <ReactECharts
          option={option}
          style={{ height: "300px", width: "100%" }}
        />
      )}
    </div>
  );
};

export default KeywordGraph;

// import React from "react";
// import ReactECharts from "echarts-for-react";

// const KeywordGraph: React.FC = () => {
//   const option = {
//     tooltip: {
//       trigger: "axis",
//     },
//     grid: {
//       left: "3%",
//       right: "4%",
//       bottom: "3%",
//       containLabel: true,
//     },
//     xAxis: {
//       type: "category",
//       boundaryGap: false,
//       data: ["2025-04-01", "2025-04-02", "2025-04-03", "2025-04-04"],
//       axisLabel: { color: "#6B7280" },
//     },
//     yAxis: {
//       type: "value",
//       axisLabel: { color: "#6B7280" },
//     },
//     series: [
//       {
//         name: "Frequency",
//         type: "line",
//         stack: "Total",
//         smooth: true,
//         lineStyle: {
//           color: "#FA4616",
//           width: 3,
//         },
//         itemStyle: {
//           color: "#FA4616",
//         },
//         areaStyle: {
//           color: "#FFECE6",
//         },
//         data: [20, 35, 25, 50],
//       },
//     ],
//   };

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
//         Keyword Frequency Over Time
//       </h2>
//       <ReactECharts
//         option={option}
//         style={{ height: "300px", width: "100%" }}
//       />
//     </div>
//   );
// };

// export default KeywordGraph;
