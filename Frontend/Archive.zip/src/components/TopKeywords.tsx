import React, { useEffect, useState } from "react";
import ReactECharts from "echarts-for-react";

type KeywordStat = {
  keyword: string;
  count: number;
};

const TopKeywords: React.FC = () => {
  const [data, setData] = useState<KeywordStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchKeywords = async () => {
      try {
        const res = await fetch(
          "http://localhost:5000/api/compliance/top-keywords"
        );
        if (!res.ok) throw new Error("Failed to fetch keywords");
        const json = await res.json();
        setData(json);
      } catch (err: any) {
        setError(err.message || "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchKeywords();
  }, []);

  const chartOption = {
    tooltip: {
      trigger: "item",
    },
    legend: {
      top: "bottom",
      textStyle: {
        color: "#6B7280",
        fontWeight: "500",
      },
    },
    series: [
      {
        name: "Top Keywords",
        type: "pie",
        radius: ["40%", "70%"],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: "#fff",
          borderWidth: 2,
        },
        label: {
          show: false,
          position: "center",
        },
        emphasis: {
          label: {
            show: true,
            fontSize: "18",
            fontWeight: "bold",
            color: "#1F2937",
          },
        },
        labelLine: {
          show: false,
        },
        data: data.map((k) => ({
          value: k.count,
          name: k.keyword,
        })),
        color: ["#FA4616", "#004F71", "#E38971", "#850000"],
      },
    ],
  };

  return (
    <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
        Top Triggered Keywords
      </h2>

      {loading && <p className="text-sm text-neutral-500">Loading...</p>}
      {error && <p className="text-sm text-red-500">Error: {error}</p>}

      {!loading && !error && (
        <ReactECharts
          option={chartOption}
          style={{ height: "300px", width: "100%" }}
        />
      )}
    </div>
  );
};

export default TopKeywords;

// import React from "react";
// import ReactECharts from "echarts-for-react";

// const TopKeywords: React.FC = () => {
//   const option = {
//     tooltip: {
//       trigger: "item",
//     },
//     legend: {
//       top: "bottom",
//       textStyle: {
//         color: "#6B7280",
//         fontWeight: "500",
//       },
//     },
//     series: [
//       {
//         name: "Top Keywords",
//         type: "pie",
//         radius: ["40%", "70%"], // Donut
//         avoidLabelOverlap: false,
//         itemStyle: {
//           borderRadius: 10,
//           borderColor: "#fff",
//           borderWidth: 2,
//         },
//         label: {
//           show: false,
//           position: "center",
//         },
//         emphasis: {
//           label: {
//             show: true,
//             fontSize: "18",
//             fontWeight: "bold",
//             color: "#1F2937",
//           },
//         },
//         labelLine: {
//           show: false,
//         },
//         data: [
//           { value: 40, name: "Confidential" },
//           { value: 30, name: "Phishing" },
//           { value: 20, name: "Harassment" },
//           { value: 10, name: "GDPR" },
//         ],
//         color: ["#FA4616", "#004F71", "#E38971", "#850000"],
//       },
//     ],
//   };

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
//         Top Triggered Keywords
//       </h2>
//       <ReactECharts
//         option={option}
//         style={{ height: "300px", width: "100%" }}
//       />
//     </div>
//   );
// };

// export default TopKeywords;

// // // src/components/TopKeywords.tsx
// // import React from "react";
// // import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

// // const TopKeywords: React.FC = () => {
// //   const data = [
// //     { name: "Confidential", value: 40 },
// //     { name: "Phishing", value: 30 },
// //     { name: "Harassment", value: 20 },
// //     { name: "GDPR", value: 10 },
// //   ];

// //   const COLORS = ["#FA4616", "#004F71", "#E38971", "#850000"];

// //   return (
// //     <div className="bg-white rounded-xl shadow p-4">
// //       <h2 className="text-xl font-semibold mb-4 text-gray-700">
// //         Top Triggered Keywords
// //       </h2>
// //       <ResponsiveContainer width="100%" height={200}>
// //         <PieChart>
// //           <Pie data={data} dataKey="value" outerRadius={70} label>
// //             {data.map((_entry, index) => (
// //               <Cell key={index} fill={COLORS[index % COLORS.length]} />
// //             ))}
// //           </Pie>
// //           <Tooltip />
// //         </PieChart>
// //       </ResponsiveContainer>
// //     </div>
// //   );
// // };

// // export default TopKeywords;
