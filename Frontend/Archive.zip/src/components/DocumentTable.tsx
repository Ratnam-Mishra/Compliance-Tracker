// import React, { useState } from "react";

// interface Props {
//   searchQuery: string;
// }

// type Document = {
//   fileName: string;
//   fileUrl: string;
//   embedded?: boolean;
// };

// const DocumentTable: React.FC<Props> = ({ searchQuery }) => {
//   const [docs] = useState<Document[]>([
//     {
//       fileName: "Compliance_Policies_Test.pdf",
//       fileUrl:
//         "https://tvmpp.sharepoint.com/sites/RAGTracker/ComplianceSecurityPolicies/Compliance_Policies_Test.pdf",
//       embedded: true,
//     },
//     {
//       fileName: "Security_Policies_Test.pdf",
//       fileUrl:
//         "https://tvmpp.sharepoint.com/sites/RAGTracker/ComplianceSecurityPolicies/Security_Policies_Test.pdf",
//       embedded: false,
//     },
//     {
//       fileName: "CodeOfConduct.docx",
//       fileUrl: "#",
//       embedded: false,
//     },
//   ]);

//   const filteredDocs = docs.filter((doc) =>
//     doc.fileName.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   return (
//     <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
//       <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
//         Documents
//       </h2>

//       <table className="w-full text-left text-neutral-700">
//         <thead>
//           <tr className="text-neutral-500 text-sm border-b border-neutral-200">
//             <th className="pb-3">Document</th>
//             <th className="pb-3">Embed Status</th>
//             <th className="pb-3">Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {filteredDocs.map((doc, index) => (
//             <tr key={index} className="hover:bg-neutral-50 text-sm">
//               <td className="py-3 font-medium">{doc.fileName}</td>
//               <td className="py-3">
//                 {doc.embedded ? (
//                   <span className="text-green-500 font-medium">Embedded</span>
//                 ) : (
//                   <span className="text-red-500 font-medium">Not Embedded</span>
//                 )}
//               </td>
//               <td className="py-3">
//                 <a
//                   href={doc.fileUrl}
//                   className="text-blue-500 hover:underline text-sm"
//                   target="_blank"
//                   rel="noopener noreferrer"
//                 >
//                   Open in SharePoint
//                 </a>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default DocumentTable;

import React, { useEffect, useState } from "react";

interface Props {
  searchQuery: string;
}

type Document = {
  fileName: string;
  fileUrl: string;
  embedded?: boolean;
};

const DocumentTable: React.FC<Props> = ({ searchQuery }) => {
  const [docs, setDocs] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const res = await fetch(
          "http://localhost:5000/api/Compliance/GetDocuments"
        );
        if (!res.ok) throw new Error("Failed to fetch documents");
        const json = await res.json();
        const withEmbedStatus = json.map((doc: Document) => ({
          ...doc,
          embedded: false,
        }));
        setDocs(withEmbedStatus);
      } catch (err: any) {
        setError(err.message || "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchDocuments();
  }, []);

  const filteredDocs = docs.filter((doc) =>
    doc.fileName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <h2 className="text-2xl font-semibold text-neutral-900 mb-4">
        Documents
      </h2>
      {loading && <p className="text-sm text-neutral-500">Loading...</p>}
      {error && <p className="text-sm text-red-500">Error: {error}</p>}

      {!loading && !error && (
        <table className="w-full text-left text-neutral-700">
          <thead>
            <tr className="text-neutral-500 text-sm border-b border-neutral-200">
              <th className="pb-3">Document</th>
              <th className="pb-3">Embed Status</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredDocs.map((doc, index) => (
              <tr key={index} className="hover:bg-neutral-50 text-sm">
                <td className="py-3 font-medium">{doc.fileName}</td>
                <td className="py-3">
                  {doc.embedded ? (
                    <span className="text-green-500 font-medium">Embedded</span>
                  ) : (
                    <span className="text-red-500 font-medium">
                      Not Embedded
                    </span>
                  )}
                </td>
                <td className="py-3">
                  <a
                    href={doc.fileUrl}
                    className="text-blue-500 hover:underline text-sm"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Open in SharePoint
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default DocumentTable;
